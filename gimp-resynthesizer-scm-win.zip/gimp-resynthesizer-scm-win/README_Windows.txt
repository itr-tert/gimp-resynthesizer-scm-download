README_Windows.txt
2022-10-24

Installation:

  Summary: Copy "plug-ins" and "scripts" folders into gimp config folder.

  Launch install.js. If unsuccessful, do the following.

  1. - Please delete the old version to use the translated version.
  2. Open gimp config folder and prepare to paste.
     - gimp config folder is often
         %AppData%\GIMP\2.10
         ( C:\Users\YourAccount\AppData\Roaming\GIMP\2.10 )
       - 2.10 is GIMP specification version. This may change in the future.
       - Enter this path in the folder address bar and press Enter.
  3. Move mouse cursor to the resynthesizer distribution folder.
  4. Copy "plug-ins" and "scripts" folder with right click menu.
  5. Paste it into gimp config folder and overwrite it.


Tested On GIMP 2.10.32

License: GNU GENERAL PUBLIC LICENSE Version 3

Source code: https://github.com/itr-tert/gimp-resynthesizer-scm

Base Resynthesizer version: 2022-04-22
https://github.com/bootchk/resynthesizer/commit/ecfc4e7eca2080580029a2d37407e852a512ef2a
