
function main() {

  function E(x) {
    return WScriptShell.ExpandEnvironmentStrings(x);
  };

  var gimp_version;
  var gimp_config_dir_exists = false;

  var gimp_ver_to_config_dir = {
    "2.10": build_path(E("%AppData%"), "GIMP", "2.10"),
    "2.8": build_path(E("%UserProfile%"), "gimp2.8")
  };

  
  var gimp_config_dir;
  var install_code = false;
  
  var x = cmd_list("ftype", "GIMP2.xcf").stdout;

  if (0 <= x.indexOf("gimp-2.10")) {
    gimp_version = "2.10";
  }
  else if (0 <= x.indexOf("gimp-2.8")) {
    gimp_version = "2.8";
  };

  if (gimp_version !== undefined) {
    gimp_config_dir = gimp_ver_to_config_dir[gimp_version];
    gimp_config_dir_exists = FileSystem.FolderExists(gimp_config_dir);
  }
  else {
    for (var ver in gimp_ver_to_config_dir) {
      var dir = gimp_ver_to_config_dir[ver];
      if (FileSystem.FolderExists(dir)) {
        gimp_config_dir = dir;
        gimp_config_dir_exists = true;
        break;
      };
    };
  };

  if (undefined !== gimp_config_dir) {
    install_code = true;
    var subdir;
    subdir = "plug-ins";
    install_code = install_code &&
      robocopy(build_path(CurrentScriptDir, subdir), build_path(gimp_config_dir, subdir));

    subdir = "scripts";
    install_code = install_code &&
      robocopy(build_path(CurrentScriptDir, subdir), build_path(gimp_config_dir, subdir));
  };

  var text = "";
  if (gimp_version !== undefined) {
    text = text + "GIMP " + gimp_version + " detected.\n\n";
  }
  else {
    text = text + "GIMP not found.\n\n";
  };

  if (gimp_config_dir === undefined) {
    text = text + "GIMP config dir: not found.\n\n";
  }
  else {
    text = text + "GIMP config dir: " + gimp_config_dir + "\n\n";
  };

  if (install_code) {
    text = text + "Installation Successful.\n";
  }
  else {
    text = text + "Installation FAILED.\n";
  };
  WScript.Echo(text);
};


function robocopy(dir1, dir2) {

  var r = cmd_list("robocopy", "/NDL", "/NJH", "/NJS", "/NP", "/NS", "/NC",
      "/S", "/W:1", "/R:2", dir1, dir2);

  return (8 > r.code);
};


function build_path() {
  if (arguments.length == 0) {
    return "";
  };
  var x = arguments[0];
  for (var i = 1; i < arguments.length; ++i) {
    x = FileSystem.BuildPath(x, arguments[i]);
  };
  return x;
};

var WScriptShell = new ActiveXObject("WScript.Shell");
var FileSystem = new ActiveXObject("Scripting.FileSystemObject");
var CurrentScriptDir = FileSystem.GetFile(WScript.ScriptFullName).ParentFolder;

function double_quote(str) {
  if( str === undefined ){
    return '""';
  };
  str = "" + str;
  str = str.replace(/"/g,'\\"');
  return '"' + str + '"';
};


try {
  WScript.Sleep(0);
  function sleep(milli_sec) {
    WScript.Sleep(milli_sec);
  };
} catch (x) {
  function sleep(milli_sec) {
    var second = Math.floor(milli_sec / 1000);
    WScriptShell.Run("Timeout.exe /t " + second, 0, true);
  };
};


function cmd_line(str) {
  var read_size = 512;
  var result = {};
  var count = 0;
  result.stdout = "";
  result.stderr = "";
  
  var wExec = WScriptShell.Exec(str);
  for ( ; wExec.Status == 0; ) {
    sleep(1);
    if(! wExec.StdOut.AtEndOfStream) {
      result.stdout += wExec.StdOut.Read(read_size);
    };
  };
  for ( ; ! wExec.StdOut.AtEndOfStream; ){
    result.stdout += wExec.StdOut.Read(read_size);
  };
  
  if( ! wExec.StdErr.AtEndOfStream ) {
	  result.stderr = wExec.StdErr.ReadAll();
  };

  result.code = wExec.ExitCode;

  return result;
};


function cmd_list() {
  if (arguments.length == 0) {
    return {stdout:"", stderr:"", code:0};
  };

  var str = "";
  for( var i = 0 , l = arguments.length; i != l; ++i) {
    if(typeof(arguments[i]) != "undefined") {
      if (0 <= arguments[i].indexOf('"') ||
          0 <= arguments[i].indexOf(' ') ) {
        str += " " + double_quote(arguments[i]);
      }
      else {
        str += " " + arguments[i];
      };
    };
  };
  return cmd_line("cmd /c " + str);
};


main();
